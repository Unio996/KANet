import Database from 'better-sqlite3';

const db = new Database(':memory:');
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Need relay_nodes table first
db.exec(`CREATE TABLE IF NOT EXISTS relay_nodes (id TEXT PRIMARY KEY, name TEXT, address TEXT, mnemonic_encrypted TEXT, network TEXT, created_at TEXT, updated_at TEXT, is_bot_autoreply INTEGER DEFAULT 0)`);

// v68 migration (exact copy of what's in migrate.js)
db.exec(`
  CREATE TABLE IF NOT EXISTS retail_dex_orders (
    id TEXT PRIMARY KEY,
    user_kasia_address TEXT NOT NULL,
    side TEXT NOT NULL CHECK(side IN ('buy_kas','sell_kas')),
    order_type TEXT NOT NULL CHECK(order_type IN ('market','limit')),
    qty TEXT NOT NULL,
    price TEXT,
    pay_chain TEXT,
    pay_address TEXT,
    receive_address TEXT,
    quoted_usdt TEXT,
    state TEXT NOT NULL DEFAULT 'aligning' CHECK(state IN ('aligning','confirming','awaiting_payment','paid','executing','completed','refunding','refunded','failed','expired')),
    pay_tx_hash TEXT,
    exchange_offer_id TEXT,
    deliver_tx_hash TEXT,
    refund_tx_hash TEXT,
    error_reason TEXT,
    expires_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_retail_dex_user ON retail_dex_orders(user_kasia_address, state);
  CREATE INDEX IF NOT EXISTS idx_retail_dex_state ON retail_dex_orders(state, updated_at);
`);
console.log('[migrate] v68: retail_dex_orders table created.');

const hasCol = db.prepare("PRAGMA table_info(relay_nodes)").all()
  .some(c => c.name === 'is_dex_broker');
if (!hasCol) {
  db.exec(`ALTER TABLE relay_nodes ADD COLUMN is_dex_broker INTEGER DEFAULT 0`);
  console.log('[migrate] v68: relay_nodes.is_dex_broker column added.');
}

// Verify
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
console.log('Tables:', tables.map(t=>t.name).join(', '));

const idx = db.prepare("SELECT name FROM sqlite_master WHERE type='index'").all();
console.log('Indexes:', idx.map(i=>i.name).join(', '));

const cols = db.prepare('PRAGMA table_info(retail_dex_orders)').all();
console.log('retail_dex_orders columns:', cols.map(c=>c.name).join(', '));
console.log('relay_nodes columns:', db.prepare('PRAGMA table_info(relay_nodes)').all().map(c=>c.name).join(', '));

// Check CHECK constraints exist
const checks = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='retail_dex_orders'").get();
console.log('Full DDL:', checks.sql);

// Re-run idempotent test
console.log('\n--- Idempotent re-run ---');
db.exec(`
  CREATE TABLE IF NOT EXISTS retail_dex_orders (
    id TEXT PRIMARY KEY,
    user_kasia_address TEXT NOT NULL,
    side TEXT NOT NULL CHECK(side IN ('buy_kas','sell_kas')),
    order_type TEXT NOT NULL CHECK(order_type IN ('market','limit')),
    qty TEXT NOT NULL,
    price TEXT,
    pay_chain TEXT,
    pay_address TEXT,
    receive_address TEXT,
    quoted_usdt TEXT,
    state TEXT NOT NULL DEFAULT 'aligning' CHECK(state IN ('aligning','confirming','awaiting_payment','paid','executing','completed','refunding','refunded','failed','expired')),
    pay_tx_hash TEXT,
    exchange_offer_id TEXT,
    deliver_tx_hash TEXT,
    refund_tx_hash TEXT,
    error_reason TEXT,
    expires_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_retail_dex_user ON retail_dex_orders(user_kasia_address, state);
  CREATE INDEX IF NOT EXISTS idx_retail_dex_state ON retail_dex_orders(state, updated_at);
`);
const hasCol2 = db.prepare("PRAGMA table_info(relay_nodes)").all()
  .some(c => c.name === 'is_dex_broker');
if (!hasCol2) {
  db.exec(`ALTER TABLE relay_nodes ADD COLUMN is_dex_broker INTEGER DEFAULT 0`);
}
console.log('Idempotent re-run: OK');

// Test CHECK constraint works
try {
  db.prepare("INSERT INTO retail_dex_orders (id, user_kasia_address, side, order_type, qty, state, created_at, updated_at) VALUES (?, 'kaspa:xxx', 'buy_kas', 'market', '10', 'aligning', ?, ?)")
    .run('test-1', new Date().toISOString(), new Date().toISOString());
  console.log('INSERT aligning: OK');
} catch (e) { console.log('INSERT aligning: FAIL -', e.message); }

try {
  db.prepare("INSERT INTO retail_dex_orders (id, user_kasia_address, side, order_type, qty, state, created_at, updated_at) VALUES (?, 'kaspa:xxx', 'invalid_side', 'market', '10', 'aligning', ?, ?)")
    .run('test-2', new Date().toISOString(), new Date().toISOString());
  console.log('INSERT invalid_side: should have failed!');
} catch (e) { console.log('INSERT invalid_side: CHECK constraint OK -', e.message.split('\n')[0]); }

console.log('\nAll tests passed.');
