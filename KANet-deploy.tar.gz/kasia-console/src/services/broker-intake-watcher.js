// broker-intake-watcher.js — Phase 3 兜底机制 (v2.1 §4.2)
// 每 60s 扫 Trader-B 入账, 4 场景路由 (意图一致/反向/陌生/黑名单). Broker 吃 gas.
// 挂在 Console 启动 (index.js) setInterval, 不新建表只新增 event_type='broker_intake_processed' 作处理标记.

import { sqlite } from '../db/client.js';

const TICK_MS = 60_000;
const REFUND_TICK_MS = 5 * 60_000;
const BROKER_RELAY_ID = '0a8e9723-f00b-4b10-8c79-1dbd4fe3cfb0';  // Trader-B
const PUBLISH_EXPIRES_MIN = 120;
const DEFAULT_FEE_KAS = '0.1';
let _intakeInterval = null;
let _refundInterval = null;
let _sendCommandOverride = null;  // test injection
let _publishOverride = null;      // test injection (POST /api/exchange/publish)

export function _testInjectSendCommand(fn) { _sendCommandOverride = fn; }
export function _testResetSendCommand() { _sendCommandOverride = null; }
export function _testInjectPublish(fn) { _publishOverride = fn; }
export function _testResetPublish() { _publishOverride = null; }

async function _send(relayId, cmd) {
  if (_sendCommandOverride) return _sendCommandOverride(relayId, cmd);
  // R4 (T-NWT-09): broker 出链全走 broker-action-queue 单线 pump 防 UTXO 双花.
  // 其他 relay (e.g. test) 仍直走 sendCommandAsync.
  if (relayId === BROKER_RELAY_ID) {
    const { enqueue } = await import('./broker-action-queue.js');
    let kind, payload;
    if (cmd.type === 'send_message')   { kind = 'dm_quote'; payload = { message: cmd.message }; }
    else if (cmd.type === 'send_kas')  { kind = 'sendKas';  payload = { amount_kas: cmd.amount_kas, note: cmd.note }; }
    else if (cmd.type === 'send_broadcast') { kind = 'accept_v1'; payload = { channel: cmd.channel, message: cmd.message }; }
    else { kind = 'dm_quote'; payload = cmd; }
    enqueue({ kind, peer: cmd.target || null, payload });
    return { ok: true, queued: true };
  }
  const { sendCommandAsync } = await import('./relay-manager.js');
  return sendCommandAsync(relayId, cmd);
}

function _getUserPayAddress(peer) {
  let row = sqlite.prepare(
    `SELECT preferred_chain AS chain, preferred_pay_address AS address
     FROM retail_dex_user_memory WHERE user_kasia_address = ?`
  ).get(peer);
  if (row?.chain && row?.address) return row;
  row = sqlite.prepare(
    `SELECT pay_chain AS chain, pay_address AS address FROM retail_dex_orders
     WHERE user_kasia_address = ? AND pay_chain IS NOT NULL AND pay_address IS NOT NULL
     ORDER BY created_at DESC LIMIT 1`
  ).get(peer);
  return (row?.chain && row?.address) ? row : null;
}

function _getFeeKasPerOrder() {
  const r = sqlite.prepare(
    `SELECT fee_kas_per_order FROM retail_dex_broker_config WHERE broker_relay_id = ?`
  ).get(BROKER_RELAY_ID);
  return r?.fee_kas_per_order || DEFAULT_FEE_KAS;
}

async function _fetchKasPrice() {
  const { fetchKasPrice } = await import('./market-seeder.js');
  return fetchKasPrice();
}

async function _publishOffer(body) {
  if (_publishOverride) return _publishOverride(body);
  const PORT = process.env.PORT || 3100;
  const res = await fetch(`http://127.0.0.1:${PORT}/api/exchange/publish`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return res.json();
}

function findUserIntent(peerAddr) {
  return sqlite.prepare(`
    SELECT side, qty FROM retail_dex_orders
    WHERE user_kasia_address = ? AND created_at > datetime('now','-24 hours')
    AND state IN ('aligning','confirming','awaiting_payment')
    ORDER BY created_at DESC LIMIT 1
  `).get(peerAddr);
}

function isBlacklisted(peerAddr) {
  const r = sqlite.prepare(`SELECT is_blocked FROM relation_states WHERE peer_address = ? LIMIT 1`).get(peerAddr);
  return r?.is_blocked === 1;
}

function markProcessed(srcEventId, outcome) {
  sqlite.prepare(`
    INSERT INTO chain_events (txid, from_address, to_address, event_type, payload, observed_by, observed_at)
    VALUES (?, NULL, NULL, 'broker_intake_processed', ?, 'broker-intake-watcher', datetime('now'))
  `).run(`broker_intake_${srcEventId}`, JSON.stringify({ src_event_id: srcEventId, outcome }));
}

async function handleIntake(event) {
  let peer = event.from_address;
  let amount;
  try { amount = parseFloat(JSON.parse(event.payload).amount || 0); } catch { amount = 0; }
  if (amount <= 0) return markProcessed(event.id, 'skip_no_amount');
  // T-NWT-07 hack fallback: kaspa_tx_log indexer 没解 sender (verboseData 缺) → from_address NULL.
  // 用 retail_dex_orders.sell_kas + qty 接近 amount + recent + awaiting state, 反查 user_kasia_address.
  // 长期靠 J2 C 任务修 indexer 补 from_address.
  if (!peer) {
    const cand = sqlite.prepare(
      `SELECT user_kasia_address FROM retail_dex_orders
       WHERE side='sell_kas' AND state IN ('aligning','confirming','awaiting_payment')
       AND ABS(CAST(qty AS REAL) - ?) < 0.5
       AND created_at > datetime('now','-24 hours')
       ORDER BY created_at DESC LIMIT 1`
    ).get(amount);
    if (cand?.user_kasia_address) peer = cand.user_kasia_address;
  }
  if (!peer) return markProcessed(event.id, 'skip_no_peer');

  if (isBlacklisted(peer)) {
    await _send(BROKER_RELAY_ID, { type: 'send_kas', target: peer, amount_kas: amount, note: 'refund blocked peer' });
    return markProcessed(event.id, 'refund_blocked');
  }

  const intent = findUserIntent(peer);
  if (intent?.side === 'sell_kas' && Math.abs(parseFloat(intent.qty) - amount) < 0.5) {
    return _publishBrokerSellOffer(peer, amount, event.id);
  }
  if (intent?.side === 'buy_kas') {
    await _send(BROKER_RELAY_ID, { type: 'send_message', target: peer, message: `你是想买 KAS 对吧? 这 ${amount} KAS 我先收着, 要我代卖成 USDT 付你还是退回? 回复 "卖" 或 "退".` });
    return markProcessed(event.id, 'buy_intent_conflict');
  }
  await _send(BROKER_RELAY_ID, { type: 'send_message', target: peer, message: `收到你 ${amount} KAS, 你想做什么? 代卖/继续持有/退回? 12h 无回复自动退.` });
  return markProcessed(event.id, 'unsolicited_wait');
}

async function _publishBrokerSellOffer(peer, amount, eventId) {
  const userPay = _getUserPayAddress(peer);
  if (!userPay) {
    await _send(BROKER_RELAY_ID, { type: 'send_message', target: peer,
      message: `收到 ${amount} KAS, 但还没你的 USDT 收款链 + 地址. 回复 "用 bnb 0x..." 之类设置. 12h 无回复自动退.`
    });
    return markProcessed(eventId, 'await_pay_addr');
  }
  const feeKas = parseFloat(_getFeeKasPerOrder()) || 0.1;
  const netKas = amount - feeKas;
  if (netKas <= 0) {
    await _send(BROKER_RELAY_ID, { type: 'send_kas', target: peer, amount_kas: amount, note: 'amount too small for fee' });
    return markProcessed(eventId, 'amount_too_small');
  }
  let midPrice = 0;
  try { midPrice = await _fetchKasPrice(); } catch {}
  if (!midPrice || midPrice <= 0) {
    await _send(BROKER_RELAY_ID, { type: 'send_kas', target: peer, amount_kas: amount, note: 'no price feed' });
    return markProcessed(eventId, 'no_price');
  }
  const wantUsdt = (netKas * midPrice).toFixed(4);

  let res = null;
  try {
    res = await _publishOffer({
      relayNodeId: BROKER_RELAY_ID,
      give_asset: 'KAS', give_amount: String(netKas),
      want_asset: 'USDT', want_amount: wantUsdt,
      verification: 'cross_chain_tx',
      verification_meta: {
        accepted_chains: [{ chain: userPay.chain, address: userPay.address }],
        expected_asset: 'USDT',
      },
      expires_minutes: PUBLISH_EXPIRES_MIN,
      metadata: { source: 'broker-intake', user_kasia_address: peer, intent_qty: amount,
        fee_kas: feeKas, net_kas: netKas, mid_price: midPrice },
    });
  } catch (err) { res = { ok: false, error: err.message }; }

  if (!res?.ok) {
    // Q2 保险: publish 失败立即退原 KAS, broker 不持仓
    await _send(BROKER_RELAY_ID, { type: 'send_kas', target: peer, amount_kas: amount,
      note: `publish failed: ${res?.error || 'unknown'}` });
    await _send(BROKER_RELAY_ID, { type: 'send_message', target: peer,
      message: `挂单失败 (${(res?.error || 'unknown').slice(0,80)}), ${amount} KAS 已退原路.`
    });
    return markProcessed(eventId, 'publish_failed');
  }

  const addrShort = userPay.address.slice(0,10) + '...' + userPay.address.slice(-4);
  await _send(BROKER_RELAY_ID, { type: 'send_message', target: peer,
    message: `收到 ${amount} KAS ✓ 已挂 SELL 单 ${netKas} KAS → ${wantUsdt} USDT (fee ${feeKas} KAS)\n` +
             `订单: ${res.offer_id.slice(0,8)} · 2h 内有人接单 USDT 直付你 ${userPay.chain} ${addrShort}\n` +
             `广播 tx: ${res.broadcast_tx?.slice(0,16) || '?'}`
  });
  return markProcessed(eventId, `sell_published:${res.offer_id}`);
}

export async function _scanExpiredBrokerOffers() {
  const trader = sqlite.prepare(`SELECT address FROM relay_nodes WHERE id = ?`).get(BROKER_RELAY_ID);
  if (!trader) return { handled: 0, scanned: 0, reason: 'no_broker_relay' };
  const rows = sqlite.prepare(`
    SELECT id, give_amount, metadata FROM exchange_offers
    WHERE maker = ?
    AND protocol_status IN ('expired', 'cancelled', 'timed_out')
    AND give_asset = 'KAS'
    AND json_extract(metadata, '$.source') = 'broker-intake'
    AND NOT EXISTS (
      SELECT 1 FROM chain_events e
      WHERE e.event_type = 'broker_kas_refunded'
      AND e.payload LIKE '%"offer_id":"' || exchange_offers.id || '"%'
    )
    LIMIT 10
  `).all(trader.address);
  let handled = 0;
  for (const r of rows) {
    try {
      const meta = JSON.parse(r.metadata || '{}');
      const userKasia = meta.user_kasia_address;
      if (!userKasia) continue;
      const refundAmount = parseFloat(meta.intent_qty || r.give_amount);
      await _send(BROKER_RELAY_ID, { type: 'send_kas', target: userKasia, amount_kas: refundAmount,
        note: `refund expired offer ${r.id.slice(0,8)}` });
      sqlite.prepare(`
        INSERT INTO chain_events (txid, from_address, to_address, event_type, payload, observed_by, observed_at)
        VALUES (?, NULL, NULL, 'broker_kas_refunded', ?, 'broker-intake-watcher', datetime('now'))
      `).run(`refund_${r.id}`, JSON.stringify({ offer_id: r.id, user_kasia_address: userKasia, amount: refundAmount }));
      await _send(BROKER_RELAY_ID, { type: 'send_message', target: userKasia,
        message: `订单 ${r.id.slice(0,8)} 2h 无人接单, 已退 ${refundAmount} KAS 给你. broker 吃 gas.`
      });
      handled++;
    } catch (err) { console.warn(`[broker-refund] ${r.id} err: ${err.message}`); }
  }
  return { handled, scanned: rows.length };
}

// T-J2-10: 12h stale unsolicited_wait scanner — user 12h 无 ACK 自动退款
export async function _scanStaleUnsolicited() {
  const rows = sqlite.prepare(`
    SELECT p.id, p.payload
    FROM chain_events p
    WHERE p.event_type = 'broker_intake_processed'
      AND p.payload LIKE '%"outcome":"unsolicited_wait"%'
      AND julianday(p.observed_at) < julianday('now', '-12 hours')
      AND NOT EXISTS (
        SELECT 1 FROM chain_events r
        WHERE r.event_type = 'broker_unsolicited_refunded'
        AND r.payload LIKE '%"processed_event_id":"' || p.id || '"%'
      )
    LIMIT 10
  `).all();
  let handled = 0;
  for (const p of rows) {
    try {
      const ppl = JSON.parse(p.payload || '{}');
      const src = sqlite.prepare(`SELECT from_address, payload FROM chain_events WHERE id = ?`).get(ppl.src_event_id);
      if (!src?.from_address) continue;
      const amt = parseFloat(JSON.parse(src.payload || '{}').amount || 0);
      if (amt <= 0) continue;
      await _send(BROKER_RELAY_ID, { type: 'send_kas', target: src.from_address, amount_kas: amt,
        note: `12h unsolicited refund ${p.id.slice(0, 12)}` });
      sqlite.prepare(`
        INSERT INTO chain_events (txid, from_address, to_address, event_type, payload, observed_by, observed_at)
        VALUES (?, NULL, NULL, 'broker_unsolicited_refunded', ?, 'broker-intake-watcher', datetime('now'))
      `).run(`unsolicited_refund_${p.id.slice(0, 16)}`, JSON.stringify({ processed_event_id: p.id, user_kasia_address: src.from_address, amount: amt }));
      await _send(BROKER_RELAY_ID, { type: 'send_message', target: src.from_address,
        message: `12h 无回复, 已退 ${amt} KAS 给你. broker 吃 gas.` });
      handled++;
    } catch (err) { console.warn(`[broker-stale] ${p.id?.slice(0,8)} err: ${err.message}`); }
  }
  return { handled, scanned: rows.length };
}

// T-NWT-06: 同 5min sub-tick 调 utxo-splitter 给 broker 钱包补零钱, 防 Round 1 一分钟 7 撞 UTXO 风暴.
// 内置 chain_event 'broker_utxo_split' 防 4min 内重跑 (REFUND_TICK_MS 5min 偏小, 1min 缓冲).
export async function _ensureBrokerUtxoSplit() {
  const recent = sqlite.prepare(
    `SELECT 1 FROM chain_events WHERE event_type='broker_utxo_split'
     AND datetime(observed_at) > datetime('now','-4 minutes') LIMIT 1`
  ).get();
  if (recent) return { skipped: 'recent' };
  const { splitUtxos } = await import('./utxo-splitter.js');
  let result;
  try { result = await splitUtxos(BROKER_RELAY_ID); } catch (e) { return { ok: false, error: e.message }; }
  sqlite.prepare(
    `INSERT INTO chain_events (txid, from_address, to_address, event_type, payload, observed_by, observed_at)
     VALUES (?, NULL, NULL, 'broker_utxo_split', ?, 'broker-intake-watcher', datetime('now'))`
  ).run(`broker_utxo_split_${Date.now()}`, JSON.stringify({ result: result || null }));
  if (result?.split) console.log(`[broker-utxo-split] ${result.utxosBefore}→${result.utxosAfter} (fee ${result.fee||'?'} KAS)`);
  return result || { ok: false };
}

export async function intakeTick() {
  const trader = sqlite.prepare(`SELECT address FROM relay_nodes WHERE id = ?`).get(BROKER_RELAY_ID);
  if (!trader) return { handled: 0, reason: 'no_broker_relay' };
  // T-NWT-07: 源表 chain_events 'tx' inbound 永远 0 (那条 path 是 message-bound, 不是 KAS transfer).
  // 真正的 inbound tx ingest 在 kaspa_tx_log (rpc-listener.mjs 写). 改源表救 broker-intake.
  // src_event_id 在 marker payload 里现在是 string (tx_id), LIKE 模式带引号.
  const rows = sqlite.prepare(`
    SELECT k.tx_id AS id, k.tx_id AS txid, k.from_address,
           json_object('amount', CAST(k.amount AS TEXT)) AS payload
    FROM kaspa_tx_log k
    WHERE k.to_address = ?
    AND k.observed_at > datetime('now','-24 hours')
    AND NOT EXISTS (
      SELECT 1 FROM chain_events p
      WHERE p.event_type = 'broker_intake_processed'
      AND p.payload LIKE '%"src_event_id":"' || k.tx_id || '"%'
    )
    LIMIT 20
  `).all(trader.address);
  let handled = 0;
  for (const e of rows) {
    try { await handleIntake(e); handled++; }
    catch (err) { console.warn(`[broker-intake] ${e.id} err: ${err.message}`); }
  }
  return { handled, scanned: rows.length };
}

export function startIntakeWatcher() {
  if (_intakeInterval) return;
  _intakeInterval = setInterval(async () => {
    try {
      const r = await intakeTick();
      if (r && r.scanned !== undefined) {
        // 每次 tick 打存活 + 结果, J1 验收标准"[broker-intake] tick 至少一条"
        console.log(`[broker-intake] tick handled=${r.handled||0}/${r.scanned||0}`);
      }
    } catch (e) { console.error('[broker-intake]', e.message); }
  }, TICK_MS);
  if (!_refundInterval) {
    _refundInterval = setInterval(async () => {
      try {
        const r = await _scanExpiredBrokerOffers();
        if (r && r.scanned > 0) console.log(`[broker-refund] tick handled=${r.handled||0}/${r.scanned||0}`);
      } catch (e) { console.error('[broker-refund]', e.message); }
      // T-J2-10: 同 5min sub-tick 同时扫 12h unsolicited stale
      try {
        const s = await _scanStaleUnsolicited();
        if (s && s.scanned > 0) console.log(`[broker-stale] tick handled=${s.handled||0}/${s.scanned||0}`);
      } catch (e) { console.error('[broker-stale]', e.message); }
      // T-NWT-06: 同 5min sub-tick 主动 ensure broker 钱包 UTXO 数 (Round 1 UTXO 双花治本)
      try { await _ensureBrokerUtxoSplit(); } catch (e) { console.error('[broker-utxo-split]', e.message); }
    }, REFUND_TICK_MS);
  }
  console.log(`[broker-intake] watcher started for Trader-B tick=${TICK_MS}ms, refund tick=${REFUND_TICK_MS}ms`);
}

export function stopIntakeWatcher() {
  if (_intakeInterval) { clearInterval(_intakeInterval); _intakeInterval = null; }
  if (_refundInterval) { clearInterval(_refundInterval); _refundInterval = null; }
}
