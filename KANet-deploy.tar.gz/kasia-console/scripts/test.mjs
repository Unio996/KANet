#!/usr/bin/env node
// scripts/test.mjs — test-framework cli runner
// Usage: node scripts/test.mjs --case=cases/broker/foo.test.mjs
//        node scripts/test.mjs --domain=broker  (run all in domain)
//        node scripts/test.mjs --all

import path from 'node:path';
import fs from 'node:fs/promises';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { runCase, formatResult } from '../test-framework/lib/runner.mjs';

const args = process.argv.slice(2);
function arg(name, def) {
  const a = args.find(a => a.startsWith(`--${name}=`));
  return a ? a.slice(name.length + 3) : def;
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FRAMEWORK_ROOT = path.join(__dirname, '..', 'test-framework');

async function findCases({ caseFile, domain, all }) {
  if (caseFile) {
    const abs = path.isAbsolute(caseFile) ? caseFile : path.resolve(process.cwd(), caseFile);
    return [abs];
  }
  const casesDir = path.join(FRAMEWORK_ROOT, 'cases');
  const out = [];
  async function walk(dir, currentDomain) {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) await walk(full, currentDomain || e.name);
      else if (e.name.endsWith('.test.mjs')) {
        if (!domain || currentDomain === domain) out.push(full);
      }
    }
  }
  await walk(casesDir, null);
  return out;
}

async function main() {
  const caseFile = arg('case');
  const domain = arg('domain');
  const tag = arg('tag');  // 用于 git hook critical 优先 (--tag=critical 跑所有标 critical 的 case)
  const allFlag = args.includes('--all');
  const quietFlag = args.includes('--quiet');  // 只输出 summary, 不 dump 每 case 详情 (post-commit 用)
  if (!caseFile && !domain && !tag && !allFlag) {
    console.log('Usage: node scripts/test.mjs --case=<path> | --domain=<broker|seeker|...> | --tag=<critical|security|...> | --all');
    console.log('       --quiet  仅输出 summary');
    process.exit(1);
  }

  const files = await findCases({ caseFile, domain, all: allFlag || !!tag });
  if (files.length === 0) {
    console.log('No matching test cases found.');
    process.exit(1);
  }

  let totalPass = 0, totalFail = 0, totalSkipped = 0;
  const summary = [];
  const isBatch = !caseFile;  // batch = --domain / --all / --tag (multiple files)
  for (const file of files) {
    const mod = await import(pathToFileURL(file).href);
    const testCase = mod.default;
    if (!testCase?.id) {
      if (!quietFlag) console.log(`SKIP (no default export): ${file}`);
      continue;
    }
    // tag filter (case 必含此 tag)
    if (tag && !(testCase.tags || []).includes(tag)) continue;
    if (isBatch && testCase.skip_in_batch) {
      if (!quietFlag) console.log(`SKIP (manual-only): ${testCase.id}`);
      totalSkipped++;
      continue;
    }
    const result = await runCase(testCase);
    if (!quietFlag) {
      console.log(formatResult(result));
      console.log('');
    } else {
      console.log(`${result.pass ? '✓' : '✗'} ${result.id}`);
    }
    if (result.pass) totalPass++; else totalFail++;
    summary.push({ id: result.id, pass: result.pass, failed: result.failed_assertions });
  }

  console.log('='.repeat(60));
  console.log(`Summary: ${totalPass} PASS / ${totalFail} FAIL / ${totalPass + totalFail} run`);
  if (totalFail > 0 && quietFlag) {
    // 失败时打 fail case 简要给 hook 用
    for (const s of summary) {
      if (!s.pass) console.log(`  FAIL ${s.id}: ${s.failed?.map(f => f.key).join(', ')}`);
    }
  }
  process.exit(totalFail > 0 ? 1 : 0);
}

main().catch(err => {
  console.error('Runner error:', err);
  process.exit(2);
});
