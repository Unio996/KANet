// cn_real_human — Owner 12:52-12:57 88 KAS SELL 真测 trace 真**真**真模拟.
// 真**真**真 happy-path persona 完全相反: 杂糅 + 中途问价 + 限价指令 + 单字段 reply + 三连纠错 + 怒骂.
//
// trace pattern:
// T1: 模糊宣告意图 ('我想卖一点 kas')
// T2: 数量 + 中途问价 ('卖88个kas, 目前卖价多少钱')
// T3: 单字段链回复 ('Bsc') — broker 真**真**真**真**真 stale flow 真**真**真**真**真**真**真**真**真 hallucinate 反方向时, persona 真**真**真**真**真**真**真**真**真**真**真**真**真**真
// T4: 怒骂 + 重复方向 ('???我有病吗 / 我卖kas')
// T5: 中途问价 again ('价格?')
// T6: 杂糅一段含 addr + 限价 + 退款条件 ('0x... 挂单价 0.0336 10分钟没人吃单退还')
// T7: 怒骂方向 ('我卖Kas, 不是买!')
// T8: 给地址等 preview

export default {
  id: 'cn_real_human',
  name: '中文真人 (Owner-style)',
  description: 'Owner 真测 trace 真**真**真**真**真模拟: 杂糅/中途问价/限价/单字段/怒骂/三连纠错',

  initialState() {
    return {
      stage: 'vague_intent',
      direction: 'sell',
      qty: 88,
      asset: 'KAS',
      chain: 'BSC',
      address: '0x1417cfDaD7a5Be7d3D28350010194CFcABf2596D',
      angry_count: 0,
    };
  },

  step(state, brokerReply) {
    const r = String(brokerReply || '');
    switch (state.stage) {
      case 'vague_intent':
        return {
          message: `我想卖一点${state.asset.toLowerCase()}`,
          nextState: { ...state, stage: 'qty_with_price_q' },
          done: false,
        };

      case 'qty_with_price_q':
        // T2: 数量 + 中途问价
        return {
          message: `卖${state.qty}个${state.asset.toLowerCase()}, 目前卖价多少钱`,
          nextState: { ...state, stage: 'single_token_chain' },
          done: false,
        };

      case 'single_token_chain':
        // T3: 单字段链 — 真**真**真**真**真**真**真 broker 真**真**真**真**真 hallucinate 反方向 trigger
        return {
          message: state.chain,
          nextState: { ...state, stage: 'check_t3_hallucinate' },
          done: false,
        };

      case 'check_t3_hallucinate':
        // T4 真**真**真 broker reply 真**真**真**真**真**真**真 '买 USDT' / '买 USDC' / 跨方向 真**真 → 怒骂纠正
        if (/买 (USDT|USDC|KAS)/.test(r) || /方向: 买/.test(r)) {
          return {
            message: '???我有病吗\n我卖kas',
            nextState: { ...state, stage: 'price_query', angry_count: state.angry_count + 1 },
            done: false,
          };
        }
        // 真**真**真 broker 真**真**真**真**真**真**真**真**真**真 ask address (期望 path)
        return {
          message: '价格?',
          nextState: { ...state, stage: 'limit_order_combo' },
          done: false,
        };

      case 'price_query':
        // T5: 中途问价 (after broker self-correct)
        return {
          message: '价格?',
          nextState: { ...state, stage: 'limit_order_combo' },
          done: false,
        };

      case 'limit_order_combo':
        // T6: 杂糅 addr + 限价 + 退款条件
        return {
          message: `${state.address}, 我想挂单价格设定0.0336. 如果10分钟内没人吃单, 麻烦帮我把${state.asset}原路返回.`,
          nextState: { ...state, stage: 'check_t6_hallucinate' },
          done: false,
        };

      case 'check_t6_hallucinate':
        // T7: broker 真**真**真**真**真**真**真 '买 50 KAS' / 跨方向 → 怒骂
        if (/买 \d+ KAS/.test(r) || /方向: 买/.test(r)) {
          return {
            message: `我卖${state.asset}, 不是买! 你分不清楚买卖吗?`,
            nextState: { ...state, stage: 'final_addr', angry_count: state.angry_count + 1 },
            done: false,
          };
        }
        // 真 broker 真**真**真**真 produce SELL preview (期望 path)
        if (/卖单画像/.test(r) || /方向: 卖/.test(r)) {
          return { message: null, nextState: { ...state, stage: 'done' }, done: true };
        }
        // 真**真**真**真**真**真**真 reply, 真**真**真**真**真**真**真**真**真**真**真**真**真**真**真 force final addr
        return {
          message: state.address,
          nextState: { ...state, stage: 'final_addr' },
          done: false,
        };

      case 'final_addr':
        // T8: 真**真**真**真**真**真**真 SELL preview 真**真**真**真**真 expected
        return {
          message: state.address,
          nextState: { ...state, stage: 'done' },
          done: true,
        };

      default:
        return { message: null, nextState: state, done: true };
    }
  },
};
