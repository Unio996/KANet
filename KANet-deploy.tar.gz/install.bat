@echo off
echo.
echo ========================================
echo    KANet Setup Script v1.0
echo ========================================
echo.
echo [1/5] Checking prerequisites...
where node >/dev/null 2>&1
if %errorlevel% neq 0 (
    echo   ERROR: Node.js not found
    pause
    exit /b 1
)
node --version
where npm >/dev/null 2>&1
if %errorlevel% neq 0 (
    echo   ERROR: npm not found
    pause
    exit /b 1
)
npm --version
echo   OK
echo.

echo [2/5] Creating data directories...
if not exist "kasia-console\data" mkdir "kasia-console\data"
if not exist "logs" mkdir "logs"
if not exist "kasia-relay\data" mkdir "kasia-relay\data"
echo   Done
echo.

echo [3/5] Creating config...
if not exist "kanet.env" (
    for /f "delims=" %%a in ('node -e "console.log(require(\"crypto\").randomBytes(32).toString(\"hex\"))"') do set KEY=%%a
    echo CONSOLE_ENCRYPTION_KEY=!KEY! > kanet.env
    echo   Generated kanet.env
) else (
    echo   kanet.env exists, skipping
)
echo.

echo [4/5] Installing dependencies...
for /d %%d in (*) do (
    if exist "%%d\package.json" (
        echo   %%d ...
        cd /d "%%d"
        call npm install --production
        if !errorlevel! neq 0 echo   [WARN] install failed
        cd /d "%~dp0"
    )
)
echo   Done
echo.

echo [5/5] Checking inference engine...
if exist "tools\llama-server\llama-server.exe" (
    echo   llama-server: found
) else (
    echo   llama-server: not found
)
echo.

echo ========================================
echo    KANet installed!
echo ========================================
echo Dashboard: http://localhost:3100
pause
