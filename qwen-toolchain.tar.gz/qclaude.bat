@echo off
chcp 65001 >nul 2>&1

set LITELLM_PORT=4000
set LLAMA_PORT=8000
set LITELLM_CONFIG=%~dp0tools\litellm-config.yaml
set LITELLM_LOG=%~dp0logs\litellm.log
set LITELLM_EXE=C:\Users\ADMIN\AppData\Local\Programs\Python\Python310\Scripts\litellm.exe
set PYTHONIOENCODING=utf-8

echo.
echo  QCLAUDE - Claude Code + Qwen3.6 Local Brain
echo.

curl -sf http://localhost:%LLAMA_PORT%/health >nul 2>&1
if %errorlevel% neq 0 (
    echo [FAIL] llama-server not running on port %LLAMA_PORT%
    pause
    exit /b 1
)
echo [OK] llama-server ready

curl -sf http://localhost:%LITELLM_PORT%/health/readiness >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] LiteLLM proxy already running
    goto launch
)

echo [..] Starting LiteLLM proxy...
if not exist "%~dp0logs" mkdir "%~dp0logs"
start "litellm" /B "%LITELLM_EXE%" --config "%LITELLM_CONFIG%" --port %LITELLM_PORT% --host 0.0.0.0 >"%LITELLM_LOG%" 2>&1

echo      Waiting for proxy...
timeout /t 5 /nobreak >nul

curl -sf http://localhost:%LITELLM_PORT%/health/readiness >nul 2>&1
if %errorlevel% neq 0 (
    timeout /t 5 /nobreak >nul
    curl -sf http://localhost:%LITELLM_PORT%/health/readiness >nul 2>&1
)
if %errorlevel% neq 0 (
    echo [FAIL] LiteLLM timeout. Check: %LITELLM_LOG%
    pause
    exit /b 1
)
echo [OK] LiteLLM proxy ready

:launch
echo.
echo  Starting Claude Code with Qwen3.6 brain...
echo.

set ANTHROPIC_BASE_URL=http://localhost:%LITELLM_PORT%
set ANTHROPIC_AUTH_TOKEN=sk-local-qwen36

claude --dangerously-skip-permissions %*
