#!/usr/bin/env bash
# ╔══════════════════════════════════════════╗
# ║  qclaude — Claude Code + Qwen3.6 本地脑  ║
# ║  同一个壳，不同的大脑                      ║
# ╚══════════════════════════════════════════╝
#
# 用法：
#   bash qclaude.sh              # 启动 LiteLLM + Claude Code（本地模式）
#   bash qclaude.sh --proxy-only # 只启动 LiteLLM 代理
#   bash qclaude.sh --stop       # 停止 LiteLLM 代理
#
# 前提：
#   1. llama-server 已在 localhost:8000 运行（Qwen3.6 模型）
#   2. pip install litellm 已完成
#   3. Claude Code CLI 已安装

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LITELLM_PORT=4000
LITELLM_CONFIG="$SCRIPT_DIR/tools/litellm-config.yaml"
LITELLM_LOG="$SCRIPT_DIR/logs/litellm.log"
LITELLM_KEY="sk-local-qwen36"
PYTHON="C:/Users/ADMIN/AppData/Local/Programs/Python/Python310/python.exe"
export PYTHONIOENCODING=utf-8

C_RESET='\033[0m'; C_BOLD='\033[1m'; C_CYAN='\033[36m'; C_GREEN='\033[32m'; C_YELLOW='\033[33m'

# ── 停止 ──
if [[ "${1:-}" == "--stop" ]]; then
  echo -e "${C_YELLOW}停止 LiteLLM 代理...${C_RESET}"
  powershell -Command "Get-Process -Name python* -ErrorAction SilentlyContinue | Where-Object { \$_.CommandLine -like '*litellm*' } | Stop-Process -Force" 2>/dev/null || true
  echo -e "${C_GREEN}✓ 已停止${C_RESET}"
  exit 0
fi

# ── 检查 llama-server ──
if ! curl -sf http://localhost:8000/health >/dev/null 2>&1; then
  echo -e "${C_YELLOW}⚠ llama-server 未运行 (localhost:8000)${C_RESET}"
  echo "  请先启动: bash kanet-start.sh 或手动启动 llama-server"
  exit 1
fi
echo -e "${C_GREEN}✓${C_RESET} llama-server 就绪 (Qwen3.6)"

# ── 启动 LiteLLM 代理 ──
if curl -sf http://localhost:$LITELLM_PORT/health >/dev/null 2>&1; then
  echo -e "${C_GREEN}✓${C_RESET} LiteLLM 代理已在运行 (port $LITELLM_PORT)"
else
  echo -e "${C_CYAN}→${C_RESET} 启动 LiteLLM 代理 (port $LITELLM_PORT)..."
  mkdir -p "$SCRIPT_DIR/logs"
  "C:/Users/ADMIN/AppData/Local/Programs/Python/Python310/Scripts/litellm.exe" --config "$LITELLM_CONFIG" --port $LITELLM_PORT --host 0.0.0.0 > "$LITELLM_LOG" 2>&1 &
  LITELLM_PID=$!
  echo "$LITELLM_PID" > "$SCRIPT_DIR/logs/pids/litellm.pid"

  # 等待就绪
  for i in $(seq 1 15); do
    if curl -sf http://localhost:$LITELLM_PORT/health >/dev/null 2>&1; then
      echo -e "${C_GREEN}✓${C_RESET} LiteLLM 代理就绪 (PID $LITELLM_PID)"
      break
    fi
    sleep 1
  done
fi

if [[ "${1:-}" == "--proxy-only" ]]; then
  echo -e "\n${C_BOLD}LiteLLM 代理运行中${C_RESET}"
  echo "  端点: http://localhost:$LITELLM_PORT"
  echo "  停止: bash qclaude.sh --stop"
  exit 0
fi

# ── 启动 Claude Code（本地模式）──
echo ""
echo -e "${C_BOLD}${C_CYAN}╔══════════════════════════════════════╗${C_RESET}"
echo -e "${C_BOLD}${C_CYAN}║${C_RESET}${C_BOLD}  Q C L A U D E  —  本 地 模 式      ${C_CYAN}║${C_RESET}"
echo -e "${C_BOLD}${C_CYAN}║${C_RESET}  Claude Code 壳 + Qwen3.6 脑        ${C_CYAN}${C_BOLD}║${C_RESET}"
echo -e "${C_BOLD}${C_CYAN}╚══════════════════════════════════════╝${C_RESET}"
echo ""

export ANTHROPIC_BASE_URL="http://localhost:$LITELLM_PORT"
export ANTHROPIC_AUTH_TOKEN="$LITELLM_KEY"

# 启动 Claude Code
claude "$@"
